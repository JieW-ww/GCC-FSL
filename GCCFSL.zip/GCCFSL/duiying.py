import numpy as np
import torch
#
def indexy(a):
    m, n = a.shape
    index = int(a.argmin())
    x = int(index / n)
    y = index % n
    return x, y
#
def clc(dataf, number):
    min_value = max(max(row) for row in dataf) * 2
    cun = np.zeros([number, 2])
    for i in range(number):
        x, y = indexy(dataf)
            #     dataf = np.delete(dataf, x, axis=0)
        cun[x][0] = x
        cun[x][1] = y
        dataf[x, :] = min_value
        dataf[:, y] = min_value

    return cun













