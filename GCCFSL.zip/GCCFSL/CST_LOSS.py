from copy import deepcopy
import torch
from torch import nn
from sklearn import preprocessing
import numpy as np
import warnings
warnings.filterwarnings("ignore", message="Numerical issues were encountered ")





class MMD_loss(nn.Module):
    def __init__(self, kernel_type='rbf', kernel_mul=2.0, kernel_num=5):
        super(MMD_loss, self).__init__()
        self.kernel_num = kernel_num
        self.kernel_mul = kernel_mul
        self.fix_sigma = None
        self.kernel_type = kernel_type

    def guassian_kernel(self, source, target, kernel_mul=2.0, kernel_num=5, fix_sigma=None):
        n_samples = int(source.size()[0]) + int(target.size()[0])
        total = torch.cat([source, target], dim=0)
        total0 = total.unsqueeze(0).expand(
            int(total.size(0)), int(total.size(0)), int(total.size(1)))
        total1 = total.unsqueeze(1).expand(
            int(total.size(0)), int(total.size(0)), int(total.size(1)))
        L2_distance = ((total0-total1)**2).sum(2)
        if fix_sigma:
            bandwidth = fix_sigma
        else:
            bandwidth = torch.sum(L2_distance.data) / (n_samples**2-n_samples)
        bandwidth /= kernel_mul ** (kernel_num // 2)
        bandwidth_list = [bandwidth * (kernel_mul**i)
                          for i in range(kernel_num)]
        kernel_val = [torch.exp(-L2_distance / bandwidth_temp)
                      for bandwidth_temp in bandwidth_list]
        return sum(kernel_val)

    def linear_mmd2(self, f_of_X, f_of_Y):
        loss = 0.0
        delta = f_of_X.float().mean(0) - f_of_Y.float().mean(0)
        loss = delta.dot(delta.T)
        return loss

    def forward(self, source, target):
        if self.kernel_type == 'linear':
            return self.linear_mmd2(source, target)
        elif self.kernel_type == 'rbf':
            batch_size = int(source.size()[0])
            kernels = self.guassian_kernel(
                source, target, kernel_mul=self.kernel_mul, kernel_num=self.kernel_num, fix_sigma=self.fix_sigma)
            with torch.no_grad():
                XX = torch.mean(kernels[:batch_size, :batch_size])
                YY = torch.mean(kernels[batch_size:, batch_size:])
                XY = torch.mean(kernels[:batch_size, batch_size:])
                YX = torch.mean(kernels[batch_size:, :batch_size])
                loss = torch.mean(XX + YY - XY - YX)
                del XX, YY, XY, YX
            # torch.cuda.empty_cache()
            return loss

def MLP(in_channel, hid, out_channel):
    """ Multi-layer perceptron """
    layer = nn.Sequential(
        nn.Conv1d(in_channels=in_channel, out_channels=hid, kernel_size=3, stride=1, padding=1, bias=False),
        nn.BatchNorm1d(hid),
        nn.ReLU(inplace=True),
        nn.Conv1d(in_channels=hid, out_channels=out_channel, kernel_size=3, stride=1, padding=1, bias=False),
        nn.BatchNorm1d(out_channel),
        # nn.ReLU(inplace=True)
    )
    return layer

class CCST_loss(nn.Module):
    def __init__(self, in_channel, hid, out_channel):
        super().__init__()
        self.mlp_s = MLP(in_channel, hid, out_channel)
        self.mlp_t = MLP(in_channel, hid, out_channel)
        self.MMD_loss = MMD_loss(kernel_type='rbf')


    def forward(self, data_src, data_tar):
        dev = data_src.device
        f_src = torch.tensor(data_src.squeeze(0).cpu().detach().numpy()).to(dev).unsqueeze(0).transpose(2, 1)
        f_tar = torch.tensor(data_tar.squeeze(0).cpu().detach().numpy()).to(dev).unsqueeze(0).transpose(2, 1)
        src_out = self.mlp_s(f_src)
        tar_out = self.mlp_t(f_tar)
        src_mlp = src_out.squeeze(0).transpose(1, 0)
        tar_mlp = tar_out.squeeze(0).transpose(1,0)
        return self.MMD_loss(src_mlp, tar_mlp)






