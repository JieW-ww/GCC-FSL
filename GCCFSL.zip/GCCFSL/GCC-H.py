import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
from torch.optim.lr_scheduler import StepLR
from torch.utils.data import DataLoader, Dataset
from torch.utils.data.sampler import Sampler
import numpy as np
import os
import math
import argparse
import scipy as sp
import scipy.stats
import pickle
import random
import scipy.io as sio
from sklearn.decomposition import PCA
from sklearn import metrics
import matplotlib.pyplot as plt
from scipy.io import loadmat
from sklearn import preprocessing
from sklearn.neighbors import KNeighborsClassifier
from matplotlib import pyplot
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
import time
import utils
import imp
from feature_net import Network
from datapro import get_target_dataset
# from model.IDE_block import DPGN
# import model.CSA_block as CSA_block
import scipy.io as io
from sklearn.neighbors import kneighbors_graph
from GCN_model import *
import torch.optim as optim
from linjie import *
from CST_LOSS import *
from duiying import *

parser = argparse.ArgumentParser(description="Few Shot Visual Recognition")
parser.add_argument('--config', type=str, default=os.path.join('./config', 'H.py'),
                    help='config file with parameters of the experiment. '
                         'It is assumed that the config file is placed under the directory ./config')
args = parser.parse_args()

# Hyper Parameters
config = imp.load_source("", args.config).config
train_opt = config['train_config']
data_path = config['data_path']
save_path = config['save_path']
source_data = config['source_data']
target_data = config['target_data']
target_data_gt = config['target_data_gt']

patch_size = train_opt['patch_size']
emb_size = train_opt['d_emb']
SRC_INPUT_DIMENSION = train_opt['src_input_dim']
TAR_INPUT_DIMENSION = train_opt['tar_input_dim']
N_DIMENSION = train_opt['n_dim']
CLASS_NUM = train_opt['class_num']
SHOT_NUM_PER_CLASS = train_opt['shot_num_per_class']
QUERY_NUM_PER_CLASS = train_opt['query_num_per_class']
EPISODE = train_opt['episode']
LEARNING_RATE = train_opt['lr']
lambda_1 = train_opt['lambda_1']
lambda_2 = train_opt['lambda_2']
GPU = config['gpu']
TEST_CLASS_NUM = train_opt['test_class_num']  # the number of class
TEST_LSAMPLE_NUM_PER_CLASS = train_opt['test_lsample_num_per_class']  # the number of labeled samples per class

utils.same_seeds(0)

# load source data
with open(os.path.join('datasets', 'Chikusei_imdb_128.pickle'), 'rb') as handle:
    source_imdb = pickle.load(handle)
print(source_imdb.keys())
print(source_imdb['Labels'])

# process source data
data_train = source_imdb['data']
labels_train = source_imdb['Labels']
print(data_train.shape)
print(labels_train.shape)
keys_all_train = sorted(list(set(labels_train)))  # class [0,...,18]
print(keys_all_train)  # [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18]
label_encoder_train = {}
for i in range(len(keys_all_train)):
    label_encoder_train[keys_all_train[i]] = i
print(label_encoder_train)

train_set = {}
for class_, path in zip(labels_train, data_train):
    if label_encoder_train[class_] not in train_set:
        train_set[label_encoder_train[class_]] = []
    train_set[label_encoder_train[class_]].append(path)
print(train_set.keys())
data = train_set
del train_set
del keys_all_train
del label_encoder_train

print("Num classes for source domain datasets: " + str(len(data)))
print(data.keys())
data = utils.sanity_check(data)  # 200 labels samples per class
print("Num classes of the number of class larger than 200: " + str(len(data)))

for class_ in data:
    for i in range(len(data[class_])):
        image_transpose = np.transpose(data[class_][i], (2, 0, 1))
        data[class_][i] = image_transpose

# source few-shot classification data
metatrain_data = data
print(len(metatrain_data.keys()), metatrain_data.keys())
del data

# source domain adaptation data
print(source_imdb['data'].shape)
source_imdb['data'] = source_imdb['data'].transpose((1, 2, 3, 0))
print(source_imdb['data'].shape)
print(source_imdb['Labels'])

# target data
# load target data
test_data = 'datasets/SH/DataCube2.mat'
test_label = 'datasets/SH/gt2.mat'

Data_Band_Scaler, GroundTruth = utils.load_data(test_data, test_label)

def weights_init(m):
    classname = m.__class__.__name__
    if classname.find('Conv') != -1:
        nn.init.xavier_uniform_(m.weight, gain=1)
        if m.bias is not None:
            m.bias.data.zero_()
    elif classname.find('BatchNorm') != -1:
        nn.init.normal_(m.weight, 1.0, 0.02)
        m.bias.data.zero_()
    elif classname.find('Linear') != -1:

        nn.init.xavier_normal_(m.weight)
        if m.bias is not None:
            m.bias.data = torch.ones(m.bias.data.size())


crossEntropy = nn.CrossEntropyLoss().to(GPU)
domain_criterion = nn.BCEWithLogitsLoss().to(GPU)


def euclidean_metric(a, b):
    n = a.shape[0]
    m = b.shape[0]
    a = a.unsqueeze(1).expand(n, m, -1)
    b = b.unsqueeze(0).expand(n, m, -1)
    logits = -((a - b) ** 2).sum(dim=2)
    return logits

def euclidean_metricf(a, b):
    n = a.shape[0]
    m = b.shape[0]
    a = a.unsqueeze(1).expand(n, m, -1)
    b = b.unsqueeze(0).expand(n, m, -1)
    logits = ((a - b) ** 2).sum(dim=2)
    return logits

# run 10 times
nDataSet = 1
acc = np.zeros([nDataSet, 1])
time_list = np.zeros([nDataSet, 1])
A = np.zeros([nDataSet, CLASS_NUM])
k = np.zeros([nDataSet, 1])
best_predict_all = []
best_G, best_RandPerm, best_Row, best_Column, best_nTrain = None, None, None, None, None
class_map = np.zeros((nDataSet,), dtype=np.object)
feature_emb_cell = np.zeros((nDataSet,), dtype=np.object)
test_labels_cell = np.zeros((nDataSet,), dtype=np.object)
test_labels_end, feature_emb_end = [], []

seeds = [1336, 1330, 1220, 1233, 1229, 1236, 1226, 1235, 1337, 1224]

for iDataSet in range(nDataSet):
    print('emb_size0:', emb_size)
    print('num_generation:', config['num_generation'])
    print('patch_size:', patch_size)
    # load target domain data for training and testing
    np.random.seed(seeds[iDataSet])
    train_loader, test_loader, target_da_metatrain_data, G, RandPerm, Row, Column, nTrain = get_target_dataset(
        Data_Band_Scaler=Data_Band_Scaler, GroundTruth=GroundTruth, class_num=TEST_CLASS_NUM,
        shot_num_per_class=TEST_LSAMPLE_NUM_PER_CLASS, patch_size=patch_size)
    num_supports, num_samples, query_edge_mask, evaluation_mask = utils.preprocess(CLASS_NUM, SHOT_NUM_PER_CLASS,
                                                                                   QUERY_NUM_PER_CLASS,
                                                                                   train_opt['batch_task'], GPU)
    feature_encoder = Network(patch_size, 128)
    feature_encoder_optim = torch.optim.Adam(feature_encoder.parameters(),
                                             lr=LEARNING_RATE)  # , weight_decay=train_opt['weight_decay'])
    feature_encoder.apply(weights_init)
    feature_encoder.to(GPU)
    feature_encoder.train()

    print("Training...")

    last_accuracy = 0.0
    last_accuracy_gnn = 0.0
    best_episdoe = 0
    train_loss = []
    total_hit_src, total_num_src, total_hit_tar, total_num_tar = 0.0, 0.0, 0.0, 0.05

    src_gcn_module = GCN_M(nfeat=128,
                            nhid=128,
                            nclass=1,
                            dropout=0.3).to(GPU)
    src_models = {'src_gcn_module': src_gcn_module}

    src_optim_backbone = optim.Adam(src_models['src_gcn_module'].parameters(), lr=0.001, weight_decay=0.001)
    src_optimizers = {'src_gcn_module': src_optim_backbone}

    tar_gcn_module = GCN_M(nfeat=128,
                            nhid=128,
                            nclass=1,
                            dropout=0.3).to(GPU)
    tar_models = {'tar_gcn_module': tar_gcn_module}

    tar_optim_backbone = optim.Adam(tar_models['tar_gcn_module'].parameters(), lr=0.001, weight_decay=0.001)
    tar_optimizers = {'tar_gcn_module': tar_optim_backbone}
    CST_model = CCST_loss(128, 64, 128).to(GPU)
    CCSA_block_att_optim = torch.optim.Adam(CST_model.parameters(), lr=LEARNING_RATE,
                                            weight_decay=train_opt['weight_decay'])
    CST_model.apply(weights_init)
    CST_model.train()

    train_start = time.time()
    for episode in range(EPISODE):
        # get few-shot classification samples
        task = utils.Task(metatrain_data, CLASS_NUM, SHOT_NUM_PER_CLASS, QUERY_NUM_PER_CLASS)
        support_dataloader_src = utils.get_HBKC_data_loader(task, num_per_class=SHOT_NUM_PER_CLASS, split="train",
                                                            shuffle=False)
        query_dataloader_src = utils.get_HBKC_data_loader(task, num_per_class=QUERY_NUM_PER_CLASS, split="test",
                                                          shuffle=True)

        task = utils.Task(target_da_metatrain_data, TEST_CLASS_NUM, SHOT_NUM_PER_CLASS, QUERY_NUM_PER_CLASS)
        support_dataloader_tar = utils.get_HBKC_data_loader(task, num_per_class=SHOT_NUM_PER_CLASS, split="train",
                                                            shuffle=False)
        query_dataloader_tar = utils.get_HBKC_data_loader(task, num_per_class=QUERY_NUM_PER_CLASS, split="test",
                                                          shuffle=True)

        # sample datas
        supports_src, support_labels_src = support_dataloader_src.__iter__().next()
        querys_src, query_labels_src = query_dataloader_src.__iter__().next()

        supports_tar, support_labels_tar = support_dataloader_tar.__iter__().next()
        querys_tar, query_labels_tar = query_dataloader_tar.__iter__().next()

        # calculate features
        support_features_src = feature_encoder(supports_src.to(GPU))
        query_features_src = feature_encoder(querys_src.to(GPU))
        support_features_tar = feature_encoder(supports_tar.to(GPU), domain='target')
        query_features_tar = feature_encoder(querys_tar.to(GPU), domain='target')

        # calculate prototype
        if SHOT_NUM_PER_CLASS > 1:
            support_proto_src = [support_features_src[i].reshape(CLASS_NUM, SHOT_NUM_PER_CLASS, -1).mean(dim=1) for i in
                                 range(len(support_features_src))]
            support_proto_tar = [support_features_tar[i].reshape(CLASS_NUM, SHOT_NUM_PER_CLASS, -1).mean(dim=1) for i in
                                 range(len(support_features_tar))]
        else:
            support_proto_src = support_features_src
            support_proto_tar = support_features_tar

        '''few-shot learning'''
        logits_src = euclidean_metric(query_features_src[1], support_proto_src[1])
        logits_src_tar = euclidean_metricf(support_proto_tar[0], support_proto_src[0])
        logits_src_tar1 = logits_src_tar.cpu().detach().numpy()
        logits_src_tar2 = clc(logits_src_tar1, 3)

        f_loss_src = crossEntropy(logits_src, query_labels_src.long().to(GPU))
        logits_tar = euclidean_metric(query_features_tar[1], support_proto_tar[1])
        f_loss_tar = crossEntropy(logits_tar, query_labels_tar.long().to(GPU))
        f_loss = f_loss_src + f_loss_tar


        last_layer_data_src0 = torch.cat((support_features_src[0], query_features_src[0]))
        last_layer_data_src1 = last_layer_data_src0.cpu().detach().numpy()
        labels = torch.cat((support_labels_src, query_labels_src))
        labels1 = labels.cpu().detach().numpy()
        labels2 = torch.cat((support_labels_tar, query_labels_tar))
        labels3 = labels2.cpu().detach().numpy()
        index_duiying = []

        for i in range(60):
            index_dui = logits_src_tar2[labels2[i], 1]
            for j in range(60):
                if index_dui == labels1[j]:
                    index_duiying.append(j)
                    labels1[j] = 100
                    break
        last_layer_data_src2 = last_layer_data_src1[index_duiying, :]
        last_layer_data_src3 = torch.from_numpy(last_layer_data_src2)
        last_layer_data_src = last_layer_data_src3.to(GPU)

        last_layer_data_tar = torch.cat((support_features_tar[0], query_features_tar[0]))

        # GCN_model
        src_adj_nei = aff_to_adj(last_layer_data_src)
        outputs_src = src_models['src_gcn_module'](last_layer_data_src,  src_adj_nei)
        outputs_src = F.normalize(outputs_src, dim=-1)
        tar_adj_nei = aff_to_adj(last_layer_data_tar)
        outputs_tar = tar_models['tar_gcn_module'](last_layer_data_tar,  tar_adj_nei)
        outputs_tar = F.normalize(outputs_tar, dim=-1)
        crossst_loss = CST_model(outputs_src, outputs_tar)


        # 2simloss
        out = torch.cat([outputs_tar, outputs_src], dim=0)
        temperature = 0.6
        batch_size = 60
        # [2*B, 2*B]
        sim_matrix = torch.exp(torch.mm(out, out.t().contiguous()) / temperature)
        mask = (torch.ones_like(sim_matrix) - torch.eye(2 * batch_size, device=sim_matrix.device)).bool()
        # [2*B, 2*B-1]
        sim_matrix = sim_matrix.masked_select(mask).view(2 * batch_size, -1)

        # compute loss
        pos_sim = torch.exp(torch.sum(outputs_tar * outputs_tar, dim=-1) / temperature)
        # [2*B]
        pos_sim = torch.cat([pos_sim, pos_sim], dim=0)
        f_contrastive_loss = (- torch.log(pos_sim / sim_matrix.sum(dim=-1))).mean()

        loss = f_loss + 0.001 * f_contrastive_loss  # 0.01

        # Update parameters
        feature_encoder.zero_grad()
        tar_optimizers['tar_gcn_module'].zero_grad()
        src_optimizers['src_gcn_module'].zero_grad()
        loss.backward()
        feature_encoder_optim.step()
        tar_optimizers['tar_gcn_module'].step()
        src_optimizers['src_gcn_module'].step()

        total_hit_src += torch.sum(torch.argmax(logits_src, dim=1).cpu() == query_labels_src).item()
        total_num_src += querys_src.shape[0]
        total_hit_tar += torch.sum(torch.argmax(logits_tar, dim=1).cpu() == query_labels_tar).item()
        total_num_tar += querys_tar.shape[0]

        if (episode + 1) % 100 == 0:
            train_loss.append(loss.item())
            print(
                'episode {:>3d}:   fsl loss: {:6.4f}, simclp_loss loss: {:6.4f}, crossst_loss {:6.4f}, acc_src {:6.4f}, acc_tar {:6.4f}, loss: {:6.4f}'.format(
                    episode + 1, \
                    f_loss.item(),
                    f_contrastive_loss.item(),
                    crossst_loss.item(),
                    total_hit_src / total_num_src,
                    total_hit_tar / total_num_tar,
                    loss.item()))
            print('fea_lr： {:6.6f}'.format(feature_encoder_optim.param_groups[0]['lr']))

        if (episode + 1) % 500 == 0 or episode == 0:
            # test
            print("Testing ...")
            train_end = time.time()
            feature_encoder.eval()
            total_rewards = 0
            counter = 0
            accuracies = []
            predict = np.array([], dtype=np.int64)
            predict_gnn = np.array([], dtype=np.int64)
            labels = np.array([], dtype=np.int64)

            train_datas, train_labels = train_loader.__iter__().next()
            _, train_features = feature_encoder(Variable(train_datas).to(GPU), domain='target')

            max_value = train_features.max()
            min_value = train_features.min()
            print(max_value.item())
            print(min_value.item())
            train_features = (train_features - min_value) * 1.0 / (max_value - min_value)

            KNN_classifier = KNeighborsClassifier(n_neighbors=1)
            KNN_classifier.fit(train_features.cpu().detach().numpy(), train_labels)
            test_labels_all, feature_emb = [], []
            for test_datas, test_labels in test_loader:
                batch_size = test_labels.shape[0]

                _, test_features = feature_encoder(Variable(test_datas).to(GPU), domain='target')
                feature_emb.append(test_features.cpu().detach().numpy())
                test_features = (test_features - min_value) * 1.0 / (max_value - min_value)
                predict_labels = KNN_classifier.predict(test_features.cpu().detach().numpy())

                test_labels = test_labels.numpy()
                test_labels_all.append(test_labels)
                rewards = [1 if predict_labels[j] == test_labels[j] else 0 for j in range(batch_size)]

                total_rewards += np.sum(rewards)
                counter += batch_size

                predict = np.append(predict, predict_labels)
                labels = np.append(labels, test_labels)

                accuracy = total_rewards / 1.0 / counter  #
                accuracies.append(accuracy)

            test_accuracy = 100. * total_rewards / len(test_loader.dataset)

            print('\t\tAccuracy: {}/{} ({:.2f}%)\n'.format(total_rewards, len(test_loader.dataset),
                                                           100. * total_rewards / len(test_loader.dataset)))
           
            test_end = time.time()

            # Training mode
            feature_encoder.train()
            if test_accuracy > last_accuracy:
                last_accuracy = test_accuracy
                best_episdoe = episode

                acc[iDataSet] = 100. * total_rewards / len(test_loader.dataset)
                OA = acc
                C = metrics.confusion_matrix(labels, predict)
                print(C)
                A[iDataSet, :] = np.diag(C) / np.sum(C, 1, dtype=np.float)
                best_predict_all = predict
                best_G, best_RandPerm, best_Row, best_Column, best_nTrain = G, RandPerm, Row, Column, nTrain
                k[iDataSet] = metrics.cohen_kappa_score(labels, predict)

                feature_emb_end = np.concatenate(feature_emb)
                test_labels_end = np.concatenate(test_labels_all)

            print('best episode:[{}], best accuracy={}'.format(best_episdoe + 1, last_accuracy))

    print('iter:{} best episode:[{}], best accuracy={}'.format(iDataSet, best_episdoe + 1, last_accuracy))
    print('iter:{} best episode:[{}], best accuracy_gnn={}'.format(iDataSet, best_episdoe + 1, last_accuracy_gnn))
    print("train time per DataSet(s): " + "{:.5f}".format(train_end - train_start))
    print("accuracy list: ", acc)
    print("A list: ", A)
    print("kappa list: ", k)
    print('***********************************************************************************')
    for i in range(len(best_predict_all)):
        best_G[best_Row[best_RandPerm[best_nTrain + i]]][best_Column[best_RandPerm[best_nTrain + i]]] = \
            best_predict_all[i] + 1
    class_map[iDataSet] = best_G[4:-4, 4:-4]
    time_list[iDataSet] = train_end - train_start
    feature_emb_cell[iDataSet] = feature_emb_end
    test_labels_cell[iDataSet] = test_labels_end
    if seeds[iDataSet] == 1330:
        best_G, best_RandPerm, best_Row, best_Column, best_nTrain = G, RandPerm, Row, Column, nTrain
        best_predict_all = predict
        for i in range(len(best_predict_all)):  # predict ndarray <class 'tuple'>: (9729,)
            best_G[best_Row[best_RandPerm[best_nTrain + i]]][best_Column[best_RandPerm[best_nTrain + i]]] = \
                best_predict_all[i] + 1

        hsi_pic = np.zeros((np.size(best_G, 0), np.size(best_G, 1), 3))
        for i in range(np.size(best_G, 0)):
            for j in range(np.size(best_G, 1)):
                if best_G[i][j] == 0:
                    hsi_pic[i, j, :] = [0, 0, 1]
                if best_G[i][j] == 1:
                    hsi_pic[i, j, :] = [0, 1, 0]
                if best_G[i][j] == 2:
                    hsi_pic[i, j, :] = [0.7, 0.15, 0.15]

        n = 5
        utils.classification_map(hsi_pic[4:-4, 4:-4, :], best_G[4:-4, 4:-4], 24,
                                 "classificationMap/HZ_{}shot.png".format(n))
AA = np.mean(A, 1)

AAMean = np.mean(AA, 0)
AAStd = np.std(AA)

AMean = np.mean(A, 0)
AStd = np.std(A, 0)

OAMean = np.mean(acc)
OAStd = np.std(acc)

kMean = np.mean(k)
kStd = np.std(k)
print("train time per DataSet(s): " + "{:.5f}".format(train_end - train_start))
print("test time per DataSet(s): " + "{:.5f}".format(test_end - train_end))
print("accuracy list: ", acc)
print("A list: ", A)
print("kappa list: ", k)
print("average OA: " + "{:.2f}".format(OAMean) + " +- " + "{:.2f}".format(OAStd))
print("average AA: " + "{:.2f}".format(100 * AAMean) + " +- " + "{:.2f}".format(100 * AAStd))
print("average kappa: " + "{:.4f}".format(100 * kMean) + " +- " + "{:.4f}".format(100 * kStd))
print("accuracy for each class: ")
for i in range(CLASS_NUM):
    print("Class " + str(i) + ": " + "{:.2f}".format(100 * AMean[i]) + " +- " + "{:.2f}".format(100 * AStd[i]))

best_iDataset = 0
for i in range(len(acc)):
    print('{}:{}'.format(i, acc[i]))
    if acc[i] > acc[best_iDataset]:
        best_iDataset = i

print('best acc all={}'.format(acc[best_iDataset]))




